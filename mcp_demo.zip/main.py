def main():
    print("Hello from demo!")


if __name__ == "__main__":
    main()
